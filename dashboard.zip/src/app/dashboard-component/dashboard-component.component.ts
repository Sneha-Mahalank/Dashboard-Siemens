import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-component',
  templateUrl: './dashboard-component.component.html',
  styleUrls: ['./dashboard-component.component.css']
})
export class DashboardComponentComponent {

  cards = [
    { title: 'This year Sales', cols: 2, rows: 1 },
    { title: 'Sales by Countries', cols: 1, rows: 1 },
  ];

  saleInfo = [
    { title: 'New Leads', count: '205'  },
    { title: 'Sales', count: '$4021' },
    { title: 'Orders', count: '80' },
    { title: 'Expense', count: '$1200' }
  ];

  constructor() { }
}
