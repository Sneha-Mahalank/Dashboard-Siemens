import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnChartComponentComponent } from './column-chart-component.component';

describe('ColumnChartComponentComponent', () => {
  let component: ColumnChartComponentComponent;
  let fixture: ComponentFixture<ColumnChartComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColumnChartComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnChartComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
