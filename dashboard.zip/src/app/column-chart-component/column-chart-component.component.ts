import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-column-chart-component',
  templateUrl: './column-chart-component.component.html',
  styleUrls: ['./column-chart-component.component.css']
})
export class ColumnChartComponentComponent implements OnInit {
  constructor() { }

  ngOnInit() {
    this.drawChart()
  }

  drawChart() {
    Highcharts.chart('container-column-chart', {
      chart: {
        type: 'column',
      },
      xAxis: {
        categories: [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'
        ],
        crosshair: true
      },
      yAxis: {
        min: 50,
      },
      plotOptions: {
        column: {
          pointPadding: 0.05,
          borderWidth: 0
        },
      },
      series: [{
        name: 'Tokyo',
        data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6],
        color: '#673ab7',
        type: undefined
      }, {
        name: 'New York',
        data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0],
        color: '#916dd1',
        type: undefined
      }]
    });
  }
   
}
