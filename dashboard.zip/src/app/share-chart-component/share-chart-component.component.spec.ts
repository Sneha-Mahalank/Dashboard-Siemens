import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareChartComponentComponent } from './share-chart-component.component';

describe('ShareChartComponentComponent', () => {
  let component: ShareChartComponentComponent;
  let fixture: ComponentFixture<ShareChartComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShareChartComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareChartComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
