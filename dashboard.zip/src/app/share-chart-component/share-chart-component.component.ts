import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import xrange from "highcharts/modules/xrange";

xrange(Highcharts);

@Component({
  selector: 'app-share-chart-component',
  templateUrl: './share-chart-component.component.html',
  styleUrls: ['./share-chart-component.component.css']
})
export class ShareChartComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.drawChart();
  }

  drawChart() {
    Highcharts.setOptions({
      colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
          radialGradient: {
            cx: 0.5,
            cy: 0.3,
            r: 0.7
          },
          stops: [
            [0, color],
            [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
          ]
        };
      })
    });

    Highcharts.chart('container-share-chart', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Browser market shares in January, 2018'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    connectorColor: 'silver'
                }
            }
        },
        series: [{
            name: 'Share',
            data: [
                { name: 'India', y: 61.41,  color: '#673ab7' },
                { name: 'UK', y: 11.84,  color: '#46287d', },
                { name: 'BD', y: 10.85, color: '#512e90'},
                { name: 'France', y: 4.67, color: '#5c34a4'},
                { name: 'USA', y: 4.18, color: '#673ab7' },
                { name: 'Brazil', y: 7.05, color: '#7446c4' }
            ],
            type: undefined
        }]
    });
  }
}
