import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';


@Component({
  selector: 'app-navigation-component',
  templateUrl: './navigation-component.component.html',
  styleUrls: ['./navigation-component.component.css']
})
export class NavigationComponentComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

    selectedMenu = [{ element: 'Dashboard', icon: 'dashboard' }, { element: 'UI Kits', icon: 'dashboard'}, { element: 'Extra Kits', icon: 'dashboard'}, { element: 'Apps', icon: 'dashboard' }, 
    { element: 'Charts', icon: 'dashboard' }, { element: 'Widgets', icon: 'dashboard' }, { element: 'Forms', icon: 'dashboard' } ];
    

  constructor(private breakpointObserver: BreakpointObserver) {}

}
