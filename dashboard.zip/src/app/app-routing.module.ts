import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { DashboardComponentComponent } from './dashboard-component/dashboard-component.component';

export const routes: Routes = [
  { path: 'dashboard', component: DashboardComponentComponent }
];

@NgModule({
  declarations: [],
  imports: []
})
export class AppRoutingModule { }
